package Package1;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.equalTo;

public class TC01 {
	
	RequestSpecification requestspec;
	ResponseSpecification responsespec;
	String key;
	int id;
	
	@BeforeClass
	public void setUp()
	{
		requestspec = new RequestSpecBuilder().setContentType(ContentType.JSON)
				.addHeader("Authorization", "token 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")
				.addHeader("Accept", "application/vnd.github+json")
				.setBaseUri("https://api.github.com").build();
		responsespec = new ResponseSpecBuilder().expectStatusCode(200)
				.expectContentType(ContentType.JSON)
	             .expectBody("verified", equalTo("true"))
	             .expectBody("read_only", equalTo("false")).build();
	}
	
	@Test(priority=1)
	public void  post_request()
	{
		Map <String,Object> reqBody = new HashMap<String,Object>();
		reqBody.put("key", "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCmKDoDEy5ihyI+UyuLBxwqacsY9sC70EoksQg+74slkgVZPwSA5V+Mh+9ea129fAD8ba+kA/7/+tRWRGh/Z/p8YHkHFYVpZbnsewe7tZ/fx1k2V0theOkfQa2c0Nmb/LSb4PDV8+4jRLDG1alFcqjXSB47IeK4XG7ko7tgkBhJ/e5mqdl9jFHjjK+MrI9MsB6Kml7n+UoGhuJgVjer5wpZJvgf8oxLXAnfoSgU9P6wslOQl2VosCRYVxK3dcuz4uyI55hjssIF+3hI6wSu7rGojXNmS136W3hK5nCIVMgftWGOyXeoVZ2ef5QedYitpah5vLumJQ4PpJJPKfIgJfhF");
		
		Response response=given().spec(requestspec).body(reqBody).when().post("/user/keys");
		key =response.then().extract().body().path("key");
		id =response.then().extract().body().path("id");
		System.out.println("response body is :" +response.getBody().asPrettyString());
		System.out.println("Status code of the Post request is "+ response.getStatusCode());
		System.out.println("Generated SSH Key is:   " +key);
		System.out.println("Generated ID of SSH Key is:  " +id);
		response.then().statusCode(201);
		System.out.println("Post Request Test Passed");
		

	}
	
	@Test(priority=2)
	public void  get_request()
	{
		Map <String,Object> reqBody = new HashMap<String,Object>();
		reqBody.put("key", "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCmKDoDEy5ihyI+UyuLBxwqacsY9sC70EoksQg+74slkgVZPwSA5V+Mh+9ea129fAD8ba+kA/7/+tRWRGh/Z/p8YHkHFYVpZbnsewe7tZ/fx1k2V0theOkfQa2c0Nmb/LSb4PDV8+4jRLDG1alFcqjXSB47IeK4XG7ko7tgkBhJ/e5mqdl9jFHjjK+MrI9MsB6Kml7n+UoGhuJgVjer5wpZJvgf8oxLXAnfoSgU9P6wslOQl2VosCRYVxK3dcuz4uyI55hjssIF+3hI6wSu7rGojXNmS136W3hK5nCIVMgftWGOyXeoVZ2ef5QedYitpah5vLumJQ4PpJJPKfIgJfhF");
		
		Response response=given().spec(requestspec).body(reqBody).when().get("/user/keys");
		
		System.out.println("response body is :" +response.getBody().asPrettyString());
		System.out.println("Status code of the Post request is "+ response.getStatusCode());
		response.then().statusCode(200);
		System.out.println("Get Request Test Passed");
		
		
	}
	
	@Test(priority=3)
	public void  delete_request()
	{
		Map <String,Object> reqBody = new HashMap<String,Object>();
		reqBody.put("key", "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQCmKDoDEy5ihyI+UyuLBxwqacsY9sC70EoksQg+74slkgVZPwSA5V+Mh+9ea129fAD8ba+kA/7/+tRWRGh/Z/p8YHkHFYVpZbnsewe7tZ/fx1k2V0theOkfQa2c0Nmb/LSb4PDV8+4jRLDG1alFcqjXSB47IeK4XG7ko7tgkBhJ/e5mqdl9jFHjjK+MrI9MsB6Kml7n+UoGhuJgVjer5wpZJvgf8oxLXAnfoSgU9P6wslOQl2VosCRYVxK3dcuz4uyI55hjssIF+3hI6wSu7rGojXNmS136W3hK5nCIVMgftWGOyXeoVZ2ef5QedYitpah5vLumJQ4PpJJPKfIgJfhF");
		
		Response response=given().spec(requestspec).body(reqBody).when().pathParam("id", id).delete("/user/keys/{id}");
		
		System.out.println("response body is :" +response.getBody().asPrettyString());
		System.out.println("Status code of the Post request is "+ response.getStatusCode());
		response.then().statusCode(204);
		System.out.println("Delete Request Test Passed");
		
		
	}

}
